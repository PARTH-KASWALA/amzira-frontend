'use client';

import Link from 'next/link';
import { useState } from 'react';
import { navLinks } from '@/lib/site-data';

const megaColumns = [
  {
    title: 'Shop By Product',
    links: ['Kurta Sets', 'Sherwani', 'Nehru Jackets', 'Lehengas', 'Sarees'],
  },
  {
    title: 'Shop By Occasion',
    links: ['Wedding', 'Reception', 'Sangeet', 'Mehendi', 'Festive'],
  },
  {
    title: 'Shop By Collection',
    links: ['Ceremony Edit', 'Bridal Edit', 'Guest Edit', 'Family Styling'],
  },
];

export function Header() {
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 border-b border-border bg-ivory/95 backdrop-blur">
      <div className="page-shell flex h-20 items-center justify-between gap-6">
        <Link href="/" className="flex items-center gap-3">
          <img src="/images/logo/Amzira_logo.png" alt="AMZIRA logo" className="h-11 w-auto" />
          <img src="/images/logo/Amzira_name.png" alt="AMZIRA" className="h-7 w-auto" />
        </Link>

        <nav className="hidden items-center gap-7 lg:flex">
          {navLinks.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="border-b border-transparent text-[11px] font-semibold uppercase tracking-[0.14em] hover:border-gold"
            >
              {item.label}
            </Link>
          ))}
          <div className="group relative">
            <button className="text-[11px] font-semibold uppercase tracking-[0.14em]">Shop</button>
            <div className="pointer-events-none invisible absolute right-0 top-10 w-[740px] border border-border bg-ivory p-8 opacity-0 shadow-calm transition group-hover:pointer-events-auto group-hover:visible group-hover:opacity-100">
              <div className="grid grid-cols-3 gap-8">
                {megaColumns.map((col) => (
                  <div key={col.title}>
                    <h4 className="mb-3 border-b border-border pb-2 text-[11px] font-semibold uppercase tracking-[0.12em] text-gold">
                      {col.title}
                    </h4>
                    <ul className="space-y-2 text-sm">
                      {col.links.map((link) => (
                        <li key={link}>
                          <a href="#" className="hover:text-gold">
                            {link}
                          </a>
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </nav>

        <div className="flex items-center gap-3 text-sm uppercase tracking-[0.1em]">
          <Link href="/contact" className="hidden text-[11px] font-semibold sm:block">
            Support
          </Link>
          <Link href="/cart" className="luxury-btn-outline px-4 py-2 text-[10px]">
            Cart
          </Link>
          <button className="luxury-btn-outline px-4 py-2 text-[10px] lg:hidden" onClick={() => setMobileOpen((v) => !v)}>
            Menu
          </button>
        </div>
      </div>

      {mobileOpen && (
        <div className="border-t border-border bg-ivory lg:hidden">
          <nav className="page-shell grid gap-4 py-5">
            {navLinks.map((item) => (
              <Link key={item.href} href={item.href} className="text-xs font-semibold uppercase tracking-[0.14em]" onClick={() => setMobileOpen(false)}>
                {item.label}
              </Link>
            ))}
          </nav>
        </div>
      )}
    </header>
  );
}
