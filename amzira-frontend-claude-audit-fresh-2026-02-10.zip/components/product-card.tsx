import Link from 'next/link';
import { Product, formatCurrency } from '@/lib/site-data';

type ProductCardProps = {
  product: Product;
};

export function ProductCard({ product }: ProductCardProps) {
  return (
    <article className="group border border-border bg-ivory">
      <Link href={`/products/${product.slug}`}>
        <div className="relative aspect-[3/4] overflow-hidden bg-beige">
          {product.badge && (
            <span className="absolute left-3 top-3 z-10 border border-gold bg-charcoal px-2 py-1 text-[10px] font-semibold uppercase tracking-[0.1em] text-gold">
              {product.badge}
            </span>
          )}
          <img
            src={product.image}
            alt={product.name}
            className="h-full w-full object-cover transition duration-500 group-hover:scale-[1.03]"
          />
        </div>
      </Link>
      <div className="space-y-3 p-4">
        <p className="text-[10px] uppercase tracking-[0.1em] text-charcoal/70">{product.category}</p>
        <h3 className="font-heading text-xl leading-tight">{product.name}</h3>
        <div className="flex items-baseline gap-2">
          <p className="font-heading text-2xl text-gold">{formatCurrency(product.price)}</p>
          {product.originalPrice && (
            <p className="text-sm text-charcoal/60 line-through">{formatCurrency(product.originalPrice)}</p>
          )}
        </div>
      </div>
    </article>
  );
}
