import Link from 'next/link';

const columns = [
  {
    title: 'Categories',
    links: ['Kurta Sets', 'Sherwani', 'Nehru Jackets', 'Lehengas', 'Sarees', 'Accessories'],
  },
  {
    title: 'Support',
    links: ['Track Order', 'Shipping', 'Returns', 'FAQs', 'Size Guide'],
  },
  {
    title: 'Company',
    links: ['About AMZIRA', 'Craft Story', 'Stores', 'Appointments', 'Contact'],
  },
  {
    title: 'Policies',
    links: ['Privacy Policy', 'Terms of Use', 'Refund Policy', 'Cookie Policy'],
  },
];

export function Footer() {
  return (
    <footer className="mt-20 border-t border-gold bg-charcoal text-ivory">
      <div className="page-shell py-14">
        <div className="mb-10 grid gap-10 lg:grid-cols-[1.6fr_4fr]">
          <div>
            <img src="/images/logo/Amzira_name.png" alt="AMZIRA" className="mb-5 h-7 w-auto" />
            <p className="max-w-sm text-sm text-ivory/80">
              Luxury Indian wedding and celebration wear for modern ceremonial wardrobes.
            </p>
          </div>
          <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
            {columns.map((column) => (
              <div key={column.title}>
                <h4 className="mb-4 border-b border-gold/30 pb-2 font-heading text-xs uppercase tracking-[0.14em] text-gold">
                  {column.title}
                </h4>
                <ul className="space-y-2">
                  {column.links.map((link) => (
                    <li key={link} className="text-xs text-ivory/80">
                      <a href="#" className="hover:text-gold">
                        {link}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>

        <div className="flex flex-col items-start justify-between gap-4 border-t border-border/20 pt-6 text-xs text-ivory/70 sm:flex-row">
          <p>© {new Date().getFullYear()} AMZIRA. All rights reserved.</p>
          <div className="flex gap-4 uppercase tracking-[0.1em]">
            <Link href="/contact" className="hover:text-gold">
              Contact
            </Link>
            <Link href="/about" className="hover:text-gold">
              About
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
