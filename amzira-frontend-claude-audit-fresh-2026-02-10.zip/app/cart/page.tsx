import Link from 'next/link';
import { products, formatCurrency } from '@/lib/site-data';

const cartItems = products.slice(0, 2).map((item) => ({ ...item, qty: 1 }));
const subtotal = cartItems.reduce((sum, item) => sum + item.price * item.qty, 0);

export default function CartPage() {
  return (
    <main className="page-shell py-10">
      <h1 className="editorial-title text-4xl">Cart</h1>
      <div className="divider-gold" />
      <section className="mt-8 grid gap-8 lg:grid-cols-[1fr_360px]">
        <div className="border border-border bg-ivory p-6">
          {cartItems.map((item) => (
            <article key={item.id} className="grid gap-4 border-b border-border py-5 last:border-b-0 md:grid-cols-[110px_1fr_auto]">
              <img src={item.image} alt={item.name} className="aspect-[3/4] w-[110px] border border-border object-cover" />
              <div>
                <h2 className="font-heading text-2xl">{item.name}</h2>
                <p className="mt-2 text-xs uppercase tracking-[0.1em] text-charcoal/70">Size: M • Qty: {item.qty}</p>
                <p className="mt-3 text-sm text-charcoal/75">{item.occasion} Collection</p>
              </div>
              <p className="font-heading text-3xl text-gold">{formatCurrency(item.price)}</p>
            </article>
          ))}
        </div>

        <aside className="h-fit border border-border bg-ivory p-6 lg:sticky lg:top-28">
          <h2 className="font-heading text-3xl uppercase tracking-[0.08em]">Summary</h2>
          <div className="mt-6 space-y-3 border-b border-border pb-4 text-sm">
            <div className="flex justify-between">
              <span>Subtotal</span>
              <span>{formatCurrency(subtotal)}</span>
            </div>
            <div className="flex justify-between">
              <span>Shipping</span>
              <span>Free</span>
            </div>
          </div>
          <div className="mt-4 flex justify-between font-heading text-2xl">
            <span>Total</span>
            <span className="text-gold">{formatCurrency(subtotal)}</span>
          </div>
          <Link href="/checkout" className="luxury-btn mt-6 w-full">Proceed To Checkout</Link>
          <Link href="/products" className="luxury-btn-outline mt-3 w-full">Continue Shopping</Link>
        </aside>
      </section>
    </main>
  );
}
