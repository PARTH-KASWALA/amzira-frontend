import Link from 'next/link';
import { SectionHeading } from '@/components/section-heading';
import { collections } from '@/lib/site-data';

export default function CollectionsPage() {
  return (
    <main className="page-shell py-10">
      <SectionHeading title="Collections" subtitle="Ceremony-focused edits laid out in a calm, image-first luxury structure." />
      <div className="mt-10 grid gap-8">
        {collections.map((collection, index) => (
          <article key={collection.title} className="grid items-center border border-border bg-ivory lg:grid-cols-2">
            <div className={index % 2 === 0 ? 'order-1' : 'order-1 lg:order-2'}>
              <img src={collection.image} alt={collection.title} className="aspect-[4/3] w-full object-cover" />
            </div>
            <div className={index % 2 === 0 ? 'order-2 p-10' : 'order-2 p-10 lg:order-1'}>
              <h2 className="font-heading text-4xl uppercase tracking-[0.08em]">{collection.title}</h2>
              <p className="mt-4 max-w-xl text-sm text-charcoal/80">{collection.subtitle}</p>
              <p className="mt-4 max-w-xl text-sm text-charcoal/75">
                Discover coordinated looks for groom, bride, and families in AMZIRA's signature ceremonial finish.
              </p>
              <Link href={collection.href} className="luxury-btn mt-8">Shop Collection</Link>
            </div>
          </article>
        ))}
      </div>
    </main>
  );
}
