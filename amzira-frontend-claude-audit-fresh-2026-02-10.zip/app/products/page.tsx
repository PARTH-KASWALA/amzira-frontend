import Link from 'next/link';
import { ProductCard } from '@/components/product-card';
import { SectionHeading } from '@/components/section-heading';
import { products } from '@/lib/site-data';

export default function ProductsPage({
  searchParams,
}: {
  searchParams: { category?: string; occasion?: string };
}) {
  const filtered = products.filter((product) => {
    const categoryMatch = searchParams.category ? product.category.toLowerCase() === searchParams.category.toLowerCase() : true;
    const occasionMatch = searchParams.occasion ? product.occasion.toLowerCase() === searchParams.occasion.toLowerCase() : true;
    return categoryMatch && occasionMatch;
  });

  return (
    <main className="page-shell py-10">
      <div className="mb-8 text-[11px] uppercase tracking-[0.1em] text-charcoal/70">
        <Link href="/">Home</Link> / <span>Products</span>
      </div>
      <div className="grid gap-8 lg:grid-cols-[280px_1fr]">
        <aside className="h-fit border border-border bg-ivory p-6">
          <h2 className="font-heading text-2xl uppercase tracking-[0.08em]">Filters</h2>
          <div className="mt-6 space-y-6 text-sm">
            <div>
              <h3 className="mb-2 text-[11px] font-semibold uppercase tracking-[0.12em] text-charcoal/70">Category</h3>
              <div className="space-y-2">
                {['Men', 'Women', 'Kids'].map((item) => (
                  <Link key={item} href={`/products?category=${item}`} className="block hover:text-gold">
                    {item}
                  </Link>
                ))}
              </div>
            </div>
            <div>
              <h3 className="mb-2 text-[11px] font-semibold uppercase tracking-[0.12em] text-charcoal/70">Occasion</h3>
              <div className="space-y-2">
                {['Wedding', 'Reception', 'Sangeet', 'Mehendi', 'Festive'].map((item) => (
                  <Link key={item} href={`/products?occasion=${item}`} className="block hover:text-gold">
                    {item}
                  </Link>
                ))}
              </div>
            </div>
            <Link href="/products" className="luxury-btn-outline w-full">Clear</Link>
          </div>
        </aside>

        <section>
          <SectionHeading title="Product Listing" subtitle="Calm, grid-first browsing with luxury density and large imagery." />
          <p className="mt-4 text-sm text-charcoal/70">{filtered.length} styles available</p>
          <div className="mt-8 grid gap-6 sm:grid-cols-2 xl:grid-cols-3">
            {filtered.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </section>
      </div>
    </main>
  );
}
