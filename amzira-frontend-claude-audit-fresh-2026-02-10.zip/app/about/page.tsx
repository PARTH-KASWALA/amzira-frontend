import { SectionHeading } from '@/components/section-heading';

export default function AboutPage() {
  return (
    <main>
      <section className="page-shell py-10">
        <SectionHeading title="About AMZIRA" subtitle="Luxury Indian celebrationwear with a focus on craftsmanship, ceremonial elegance, and modern confidence." />
        <div className="mt-10 grid gap-8 lg:grid-cols-2">
          <img src="/images/occasions/wedding.jpg" alt="AMZIRA craftsmanship" className="aspect-[4/5] w-full border border-border object-cover" />
          <div className="space-y-5 border border-border bg-ivory p-8 text-sm text-charcoal/85">
            <p>
              AMZIRA designs occasionwear for the modern Indian celebration wardrobe. Our design language follows traditional craft heritage and structured couture lines.
            </p>
            <p>
              From haldi mornings to reception nights, each silhouette is built for presence, comfort, and ceremony.
            </p>
            <p>
              We collaborate with artisan communities across India to preserve embroidery, weave, and finishing techniques in contemporary forms.
            </p>
          </div>
        </div>
      </section>
    </main>
  );
}
