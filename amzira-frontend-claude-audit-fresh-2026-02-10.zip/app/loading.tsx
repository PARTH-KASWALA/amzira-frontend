export default function Loading() {
  return (
    <main className="page-shell py-24 text-center">
      <p className="text-xs uppercase tracking-[0.14em] text-charcoal/70">Loading AMZIRA...</p>
    </main>
  );
}
