import Link from 'next/link';

export default function NotFound() {
  return (
    <main className="page-shell py-24 text-center">
      <h1 className="editorial-title text-4xl">Page Not Found</h1>
      <div className="divider-gold mx-auto" />
      <p className="mx-auto mt-5 max-w-xl text-sm text-charcoal/75">
        The requested page is not available in this AMZIRA experience.
      </p>
      <Link href="/" className="luxury-btn mt-8">
        Back To Home
      </Link>
    </main>
  );
}
