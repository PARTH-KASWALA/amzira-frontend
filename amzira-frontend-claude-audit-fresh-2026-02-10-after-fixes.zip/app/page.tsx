import Link from 'next/link';
import { ProductCard } from '@/components/product-card';
import { SectionHeading } from '@/components/section-heading';
import { collections, products, stories } from '@/lib/site-data';

const heroSlides = [
  { title: 'Wedding Wardrobes For The Modern Groom', subtitle: 'Royal ceremony silhouettes, refined for contemporary celebrations.', image: '/images/hero/hero-1.jpg', cta: '/products?occasion=Wedding' },
  { title: 'Bridal Couture With Indian Craft Depth', subtitle: 'Luxury lehenga stories for wedding, reception, and beyond.', image: '/images/hero/hero-3.jpg', cta: '/products?category=Women' },
];

export default function HomePage() {
  return (
    <main>
      <section className="page-shell pt-8">
        <div className="grid gap-4 lg:grid-cols-2">
          {heroSlides.map((slide) => (
            <article key={slide.title} className="relative aspect-[16/11] overflow-hidden border border-border bg-beige animate-fadeIn">
              <img src={slide.image} alt={slide.title} className="h-full w-full object-cover" />
              <div className="absolute inset-0 bg-charcoal/20" />
              <div className="absolute inset-x-8 bottom-8 max-w-xl text-ivory">
                <h1 className="font-heading text-3xl uppercase tracking-[0.08em] leading-tight sm:text-4xl">{slide.title}</h1>
                <p className="mt-3 max-w-lg text-sm text-ivory/90">{slide.subtitle}</p>
                <Link href={slide.cta} className="luxury-btn mt-6">Explore</Link>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className="page-shell mt-16">
        <SectionHeading title="Collections" subtitle="Shop AMZIRA's curated ceremony edits in the same editorial flow as premium wedding fashion houses." />
        <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {collections.map((item) => (
            <Link key={item.title} href={item.href} className="group border border-border bg-ivory">
              <div className="aspect-[3/4] overflow-hidden bg-beige">
                <img src={item.image} alt={item.title} className="h-full w-full object-cover transition duration-500 group-hover:scale-[1.03]" />
              </div>
              <div className="space-y-2 p-4">
                <h3 className="font-heading text-2xl">{item.title}</h3>
                <p className="text-sm text-charcoal/75">{item.subtitle}</p>
              </div>
            </Link>
          ))}
        </div>
      </section>

      <section className="mt-16 bg-beige py-16">
        <div className="page-shell">
          <SectionHeading title="Signature Styles" subtitle="Image-led product discovery with minimal text, inspired by luxury ceremonial ecommerce patterns." />
          <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {products.slice(0, 8).map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
          <div className="mt-10 text-center">
            <Link href="/products" className="luxury-btn">View All Products</Link>
          </div>
        </div>
      </section>

      <section className="page-shell mt-16 mb-8">
        <SectionHeading title="AMZIRA Story" subtitle="Luxury fashion commerce experience shaped by craft narrative and confident editorial simplicity." />
        <div className="mt-10 grid gap-6 md:grid-cols-3">
          {stories.map((story) => (
            <article key={story.title} className="border border-border bg-ivory p-6">
              <h3 className="font-heading text-2xl uppercase tracking-[0.06em]">{story.title}</h3>
              <p className="mt-4 text-sm text-charcoal/80">{story.body}</p>
            </article>
          ))}
        </div>
      </section>
    </main>
  );
}
