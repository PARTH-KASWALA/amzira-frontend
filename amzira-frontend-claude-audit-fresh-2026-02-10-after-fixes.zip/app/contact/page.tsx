import { SectionHeading } from '@/components/section-heading';

export default function ContactPage() {
  return (
    <main className="page-shell py-10">
      <SectionHeading title="Contact" subtitle="Connect with AMZIRA for store visits, wedding styling, and order support." />
      <section className="mt-10 grid gap-8 lg:grid-cols-[1fr_1.2fr]">
        <div className="space-y-4 border border-border bg-ivory p-8 text-sm">
          <h2 className="font-heading text-3xl uppercase tracking-[0.08em]">Client Services</h2>
          <p>Email: care@amzira.com</p>
          <p>Phone: +91 96743 73838</p>
          <p>Hours: Monday to Saturday, 10 AM - 7 PM</p>
          <p>For wedding consultations, mention event date and city in your request.</p>
        </div>

        <form className="grid gap-4 border border-border bg-ivory p-8">
          <label className="text-[11px] font-semibold uppercase tracking-[0.1em] text-charcoal/70">Full Name</label>
          <input className="border border-border bg-ivory px-4 py-3 text-sm" placeholder="Your Name" />

          <label className="text-[11px] font-semibold uppercase tracking-[0.1em] text-charcoal/70">Email</label>
          <input className="border border-border bg-ivory px-4 py-3 text-sm" placeholder="you@example.com" />

          <label className="text-[11px] font-semibold uppercase tracking-[0.1em] text-charcoal/70">Phone</label>
          <input className="border border-border bg-ivory px-4 py-3 text-sm" placeholder="+91" />

          <label className="text-[11px] font-semibold uppercase tracking-[0.1em] text-charcoal/70">Message</label>
          <textarea className="min-h-32 border border-border bg-ivory px-4 py-3 text-sm" placeholder="How can AMZIRA support your celebration wardrobe?" />

          <button type="button" className="luxury-btn mt-2 w-fit">Send Inquiry</button>
        </form>
      </section>
    </main>
  );
}
