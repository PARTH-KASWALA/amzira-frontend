import { products, formatCurrency } from '@/lib/site-data';

const checkoutItems = products.slice(0, 2);
const subtotal = checkoutItems.reduce((sum, item) => sum + item.price, 0);

export default function CheckoutPage() {
  return (
    <main className="page-shell py-10">
      <h1 className="editorial-title text-4xl">Checkout</h1>
      <div className="divider-gold" />

      <div className="mt-8 grid gap-8 lg:grid-cols-[1fr_380px]">
        <section className="space-y-6">
          <article className="border border-border bg-ivory p-6">
            <h2 className="font-heading text-3xl uppercase tracking-[0.08em]">Delivery Address</h2>
            <div className="mt-5 grid gap-4 sm:grid-cols-2">
              <input className="border border-border bg-ivory px-4 py-3 text-sm" placeholder="First Name" />
              <input className="border border-border bg-ivory px-4 py-3 text-sm" placeholder="Last Name" />
              <input className="border border-border bg-ivory px-4 py-3 text-sm" placeholder="Phone" />
              <input className="border border-border bg-ivory px-4 py-3 text-sm" placeholder="Email" />
            </div>
            <input className="mt-4 w-full border border-border bg-ivory px-4 py-3 text-sm" placeholder="Street Address" />
            <div className="mt-4 grid gap-4 sm:grid-cols-3">
              <input className="border border-border bg-ivory px-4 py-3 text-sm" placeholder="City" />
              <input className="border border-border bg-ivory px-4 py-3 text-sm" placeholder="State" />
              <input className="border border-border bg-ivory px-4 py-3 text-sm" placeholder="PIN Code" />
            </div>
          </article>

          <article className="border border-border bg-ivory p-6">
            <h2 className="font-heading text-3xl uppercase tracking-[0.08em]">Payment</h2>
            <div className="mt-5 grid gap-3">
              {['Card / UPI', 'Net Banking', 'Cash On Delivery'].map((method) => (
                <label key={method} className="flex items-center gap-3 border border-border px-4 py-3 text-sm">
                  <input type="radio" name="payment" defaultChecked={method === 'Card / UPI'} />
                  {method}
                </label>
              ))}
            </div>
            <button type="button" className="luxury-btn mt-6">Place Order</button>
          </article>
        </section>

        <aside className="h-fit border border-border bg-ivory p-6 lg:sticky lg:top-28">
          <h2 className="font-heading text-3xl uppercase tracking-[0.08em]">Order Summary</h2>
          <div className="mt-5 space-y-3 border-b border-border pb-4">
            {checkoutItems.map((item) => (
              <div key={item.id} className="flex items-center gap-3 text-sm">
                <img src={item.image} alt={item.name} className="h-16 w-12 border border-border object-cover" />
                <div className="flex-1">
                  <p className="line-clamp-2">{item.name}</p>
                  <p className="text-xs uppercase tracking-[0.08em] text-charcoal/70">Qty 1</p>
                </div>
                <p className="font-heading text-xl text-gold">{formatCurrency(item.price)}</p>
              </div>
            ))}
          </div>
          <div className="mt-4 space-y-2 text-sm">
            <div className="flex justify-between">
              <span>Subtotal</span>
              <span>{formatCurrency(subtotal)}</span>
            </div>
            <div className="flex justify-between">
              <span>Shipping</span>
              <span>Free</span>
            </div>
            <div className="mt-3 flex justify-between border-t border-border pt-3 font-heading text-2xl">
              <span>Total</span>
              <span className="text-gold">{formatCurrency(subtotal)}</span>
            </div>
          </div>
        </aside>
      </div>
    </main>
  );
}
