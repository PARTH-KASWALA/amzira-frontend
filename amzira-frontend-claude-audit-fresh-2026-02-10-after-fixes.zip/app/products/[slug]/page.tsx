import Link from 'next/link';
import { notFound } from 'next/navigation';
import { ProductCard } from '@/components/product-card';
import { products, formatCurrency } from '@/lib/site-data';

export default function ProductDetailPage({ params }: { params: { slug: string } }) {
  const product = products.find((item) => item.slug === params.slug);
  if (!product) notFound();

  const related = products.filter((item) => item.slug !== product.slug).slice(0, 4);

  return (
    <main className="page-shell py-10">
      <div className="mb-8 text-[11px] uppercase tracking-[0.1em] text-charcoal/70">
        <Link href="/">Home</Link> / <Link href="/products">Products</Link> / <span>{product.name}</span>
      </div>

      <section className="grid gap-8 lg:grid-cols-[1.1fr_1fr]">
        <div className="grid gap-3 sm:grid-cols-[96px_1fr]">
          <div className="grid gap-3 sm:grid-rows-4">
            {[product.image, product.altImage ?? product.image, product.image, product.altImage ?? product.image].map((src, idx) => (
              <img key={idx} src={src} alt={`${product.name} thumbnail ${idx + 1}`} className="aspect-[3/4] w-full border border-border object-cover" />
            ))}
          </div>
          <div className="border border-border bg-beige">
            <img src={product.image} alt={product.name} className="aspect-[3/4] w-full object-cover" />
          </div>
        </div>

        <div className="space-y-6 border border-border bg-ivory p-8 lg:sticky lg:top-28 lg:h-fit">
          <div>
            <p className="text-[10px] uppercase tracking-[0.12em] text-charcoal/70">{product.category} • {product.occasion}</p>
            <h1 className="mt-2 font-heading text-4xl uppercase tracking-[0.08em]">{product.name}</h1>
          </div>
          <div className="flex items-end gap-3">
            <p className="font-heading text-4xl text-gold">{formatCurrency(product.price)}</p>
            {product.originalPrice && <p className="text-sm text-charcoal/60 line-through">{formatCurrency(product.originalPrice)}</p>}
          </div>
          <p className="text-sm text-charcoal/80">{product.description}</p>

          <div>
            <h3 className="mb-3 text-[11px] font-semibold uppercase tracking-[0.1em] text-charcoal/70">Select Size</h3>
            <div className="flex flex-wrap gap-2">
              {['S', 'M', 'L', 'XL', 'XXL'].map((size) => (
                <button key={size} className="h-11 min-w-11 border border-border px-3 text-xs font-semibold uppercase hover:border-gold">
                  {size}
                </button>
              ))}
            </div>
          </div>

          <div className="grid gap-3 sm:grid-cols-2">
            <button className="luxury-btn">Add To Cart</button>
            <button className="luxury-btn-outline">Wishlist</button>
          </div>

          <div className="border-t border-border pt-4 text-xs text-charcoal/70">
            <p>Fabric: {product.fabric}</p>
            <p className="mt-1">Shipping: Delivered in 4-6 business days</p>
            <p className="mt-1">Returns: Easy 7-day return on unworn items</p>
          </div>
        </div>
      </section>

      <section className="mt-16">
        <h2 className="editorial-title text-3xl">You May Also Like</h2>
        <div className="divider-gold" />
        <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {related.map((item) => (
            <ProductCard key={item.id} product={item} />
          ))}
        </div>
      </section>
    </main>
  );
}
