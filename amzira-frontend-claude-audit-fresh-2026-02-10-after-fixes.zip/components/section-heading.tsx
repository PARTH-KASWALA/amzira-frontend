type SectionHeadingProps = {
  title: string;
  subtitle?: string;
  centered?: boolean;
};

export function SectionHeading({ title, subtitle, centered = false }: SectionHeadingProps) {
  return (
    <div className={centered ? 'text-center' : ''}>
      <h2 className="editorial-title text-[28px] sm:text-[36px]">{title}</h2>
      <div className={centered ? 'divider-gold mx-auto' : 'divider-gold'} />
      {subtitle ? <p className="mt-4 max-w-2xl text-sm text-charcoal/75">{subtitle}</p> : null}
    </div>
  );
}
