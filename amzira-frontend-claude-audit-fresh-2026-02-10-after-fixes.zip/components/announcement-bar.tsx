export function AnnouncementBar() {
  return (
    <div className="border-b border-gold bg-charcoal py-2 text-center text-[10px] uppercase tracking-[0.12em] text-gold sm:text-[11px]">
      Free shipping above INR 3,999 • Wedding consultation available • New ceremony arrivals
    </div>
  );
}
