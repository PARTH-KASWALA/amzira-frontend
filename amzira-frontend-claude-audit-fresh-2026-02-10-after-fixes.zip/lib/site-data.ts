export type Product = {
  id: string;
  slug: string;
  name: string;
  category: string;
  price: number;
  originalPrice?: number;
  image: string;
  altImage?: string;
  badge?: string;
  description: string;
  fabric: string;
  occasion: string;
};

export const navLinks = [
  { label: 'Home', href: '/' },
  { label: 'Collections', href: '/collections' },
  { label: 'Men', href: '/products?category=Men' },
  { label: 'Women', href: '/products?category=Women' },
  { label: 'Kids', href: '/products?category=Kids' },
  { label: 'About', href: '/about' },
  { label: 'Contact', href: '/contact' },
];

export const collections = [
  { title: 'Wedding Edit', subtitle: 'Ceremonial silhouettes for groom and guests', image: '/images/categories/men.jpg', href: '/products?occasion=Wedding' },
  { title: 'Bridal Lehengas', subtitle: 'Heirloom craft, couture presence', image: '/images/categories/women.jpg', href: '/products?category=Women' },
  { title: 'Festive Classics', subtitle: 'Contemporary kurta stories in regal palettes', image: '/images/occasions/celebrating_festivals.jpg', href: '/products?occasion=Festive' },
  { title: 'Young Royals', subtitle: 'Miniature occasionwear for every ceremony', image: '/images/categories/kids.jpg', href: '/products?category=Kids' },
];

export const products: Product[] = [
  {
    id: 'AMZ001',
    slug: 'royal-burgundy-kurta-jacket-set',
    name: 'Royal Burgundy Kurta Jacket Set',
    category: 'Men',
    price: 6299,
    originalPrice: 8999,
    image: '/images/products/product-1-front.jpg',
    altImage: '/images/products/product-1-back.jpg',
    badge: 'Bestseller',
    description: 'Structured kurta jacket ensemble with refined hand embroidery for wedding rituals.',
    fabric: 'Silk Blend',
    occasion: 'Wedding',
  },
  {
    id: 'AMZ002',
    slug: 'gold-embroidered-sherwani',
    name: 'Gold Embroidered Sherwani',
    category: 'Men',
    price: 12799,
    originalPrice: 15999,
    image: '/images/products/product-2-front.jpg',
    altImage: '/images/products/product-2-back.jpg',
    badge: 'New',
    description: 'Regal sherwani crafted for reception evenings and ceremonial portraits.',
    fabric: 'Brocade',
    occasion: 'Reception',
  },
  {
    id: 'AMZ003',
    slug: 'classic-navy-kurta',
    name: 'Classic Navy Kurta Set',
    category: 'Men',
    price: 3499,
    originalPrice: 4999,
    image: '/images/products/product-3-front.jpg',
    altImage: '/images/products/product-3-back.jpg',
    description: 'An elevated festive kurta in breathable construction and rich drape.',
    fabric: 'Cotton Satin',
    occasion: 'Festive',
  },
  {
    id: 'AMZ004',
    slug: 'maroon-indo-western',
    name: 'Maroon Indo Western',
    category: 'Men',
    price: 8799,
    originalPrice: 10999,
    image: '/images/products/product-4-front.jpg',
    altImage: '/images/products/product-4-back.jpg',
    description: 'Modern ceremony statement with structured lines and tonal texture.',
    fabric: 'Silk Jacquard',
    occasion: 'Cocktail',
  },
  {
    id: 'AMZ005',
    slug: 'ivory-ceremony-kurta',
    name: 'Ivory Ceremony Kurta',
    category: 'Men',
    price: 3149,
    originalPrice: 4499,
    image: '/images/products/product-5-front.jpg',
    altImage: '/images/products/product-5-back.jpg',
    description: 'Minimal ceremony kurta designed for layered royal styling.',
    fabric: 'Fine Cotton',
    occasion: 'Haldi',
  },
  {
    id: 'AMZ006',
    slug: 'velvet-nehru-jacket',
    name: 'Velvet Nehru Jacket',
    category: 'Men',
    price: 4199,
    originalPrice: 5999,
    image: '/images/products/product-6-front.jpg',
    altImage: '/images/products/product-6-back.jpg',
    description: 'Classic layer for evening looks with tonal gold detailing.',
    fabric: 'Velvet',
    occasion: 'Sangeet',
  },
  {
    id: 'AMZ007',
    slug: 'bridal-red-lehenga',
    name: 'Bridal Red Lehenga',
    category: 'Women',
    price: 16999,
    originalPrice: 21999,
    image: '/images/products/product-7-front.jpg',
    altImage: '/images/products/product-7-back.jpg',
    badge: 'Bridal',
    description: 'Ceremonial lehenga with couture-like volume and hand-finished borders.',
    fabric: 'Raw Silk',
    occasion: 'Wedding',
  },
  {
    id: 'AMZ008',
    slug: 'pastel-festive-lehenga',
    name: 'Pastel Festive Lehenga',
    category: 'Women',
    price: 13299,
    originalPrice: 17599,
    image: '/images/products/product-8-front.jpg',
    altImage: '/images/products/product-8-back.jpg',
    description: 'Light ceremonial lehenga designed for day celebrations and receptions.',
    fabric: 'Silk Organza',
    occasion: 'Mehendi',
  },
];

export const stories = [
  {
    title: 'Crafted in India',
    body: 'Every AMZIRA silhouette is developed through artisan clusters known for ceremonial weave and embroidery traditions.',
  },
  {
    title: 'Wedding Wardrobe Service',
    body: 'Curated styling journeys for grooms, brides, and families to ensure visual harmony through each event.',
  },
  {
    title: 'Modern Royal Codes',
    body: 'Traditional attire interpreted for contemporary confidence, movement, and editorial presence.',
  },
];

export const formatCurrency = (amount: number) =>
  new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(amount);
